#ifndef _COMMANDS_EXAMPLECOMMANDGROUP_H_
#define _COMMANDS_EXAMPLECOMMANDGROUP_H_

#include "commands/CommandGroup.h"

class ExampleCommandGroup : public CommandGroup {
public:
  ExampleCommandGroup();
};

#endif // _COMMANDS_EXAMPLECOMMANDGROUP_H_
